# Birthday Surprise Website

A simple, responsive birthday website with three steps:
1. Birthday surprise
2. Personal letter
3. Final wish

No music, no external libraries, and no paid services required.

## Preview locally
Open `index.html` in a web browser.

## Add her photo
1. Put the photo inside the `assets` folder and name it exactly `her-photo.jpg`.
2. Open `index.html` in a text editor.
3. Find the comment `PHOTO OPTION`.
4. Replace the `<div class="photo-placeholder"...> ... </div>` block with this line:

   `<img class="photo" src="assets/her-photo.jpg" alt="A favorite photo of you">`

5. Save and refresh the page.

Tip: use a photo you have permission to share, and choose a flattering crop.

## Personalize the message
In `index.html`, edit:
- `Happy Birthday, Beautiful.`
- The text inside the letter card
- The final birthday wish

## Publish free with GitHub Pages
1. Sign in or create a free account at https://github.com/
2. Create a new repository. A name such as `birthday-surprise` is fine.
3. Upload `index.html`, `README.md`, and the `assets` folder to the repository's root.
4. In the repository, open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Choose branch **main** and folder **/(root)**, then save.
7. Wait a few minutes. GitHub Pages will show your website URL on the Pages settings screen.

The URL is usually `https://YOUR-USERNAME.github.io/birthday-surprise/`.

If you change the repository name, the URL will be different. GitHub's interface may vary slightly.

## Notes
- This is a static website; it does not collect information or use a database.
- The repository may be public for GitHub Pages on a free plan, so avoid uploading private or sensitive photos.
